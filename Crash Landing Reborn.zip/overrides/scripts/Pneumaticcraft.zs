recipes.addShapeless(<PneumaticCraft:plasticPlant>, [oreDict.dyeBlack, <exnihilo:seed_grass>]);
recipes.addShapeless(<PneumaticCraft:plasticPlant:1>, [oreDict.dyeRed, <exnihilo:seed_grass>]);
recipes.addShapeless(<PneumaticCraft:plasticPlant:2>, [oreDict.dyeGreen, <exnihilo:seed_grass>]);
recipes.addShapeless(<PneumaticCraft:plasticPlant:3>, [oreDict.dyeBrown , <exnihilo:seed_grass>]);
recipes.addShapeless(<PneumaticCraft:plasticPlant:4>, [oreDict.dyeBlue, <exnihilo:seed_grass>]);
recipes.addShapeless(<PneumaticCraft:plasticPlant:5>, [oreDict.dyePurple, <exnihilo:seed_grass>]);
recipes.addShapeless(<PneumaticCraft:plasticPlant:6>, [oreDict.dyeCyan, <exnihilo:seed_grass>]);
recipes.addShapeless(<PneumaticCraft:plasticPlant:8>, [oreDict.dyeGray, <exnihilo:seed_grass>]);
recipes.addShapeless(<PneumaticCraft:plasticPlant:9>, [oreDict.dyePink, <exnihilo:seed_grass>]);
recipes.addShapeless(<PneumaticCraft:plasticPlant:10>, [oreDict.dyeLime, <exnihilo:seed_grass>]);
recipes.addShapeless(<PneumaticCraft:plasticPlant:11>, [oreDict.dyeYellow, <exnihilo:seed_grass>]);
recipes.addShapeless(<PneumaticCraft:plasticPlant:12>, [oreDict.dyeLightBlue, <exnihilo:seed_grass>]);
recipes.addShapeless(<PneumaticCraft:plasticPlant:14>, [oreDict.dyeOrange, <exnihilo:seed_grass>]);
recipes.addShapeless(<PneumaticCraft:plasticPlant:15>, [oreDict.dyeWhite, <exnihilo:seed_grass>]);
recipes.remove(<PneumaticCraft:pressureChamberWall>);
recipes.addShapeless(<PneumaticCraft:pressureChamberWall>, [<rockdigger:PressureChamberwallcorroded>, <PneumaticCraft:ingotIronCompressed>]);
recipes.addShaped(<PneumaticCraft:pressureChamberWall> *4,[ [<PneumaticCraft:ingotIronCompressed>, <PneumaticCraft:ingotIronCompressed>, <PneumaticCraft:ingotIronCompressed>],
						           [<PneumaticCraft:ingotIronCompressed>, null, <PneumaticCraft:ingotIronCompressed>],
							       [<PneumaticCraft:ingotIronCompressed>, <PneumaticCraft:ingotIronCompressed>, <PneumaticCraft:ingotIronCompressed>]]);



