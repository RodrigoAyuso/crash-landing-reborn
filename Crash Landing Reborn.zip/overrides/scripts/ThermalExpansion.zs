import mods.nei.NEI;

// --- JetPacks ---

recipes.remove(<simplyjetpacks:components:5>);
recipes.remove(<simplyjetpacks:components:11>);
recipes.remove(<simplyjetpacks:components:12>);
recipes.remove(<simplyjetpacks:components:13>);
recipes.remove(<simplyjetpacks:components:14>);
recipes.remove(<simplyjetpacks:components:15>);
NEI.hide(<simplyjetpacks:components:15>);
NEI.hide(<simplyjetpacks:jetpacks:5>);
recipes.addShaped(<simplyjetpacks:components:11>,[ [<ore:ingotLead>, <ThermalExpansion:material:1>, <ore:ingotLead>],
						              [<ThermalDynamics:ThermalDynamics_0>, <MineFactoryReloaded:upgrade.logic>, <ThermalDynamics:ThermalDynamics_0>],
							          [<ThermalExpansion:Cell:1>, <ThermalExpansion:material>, <ThermalExpansion:Cell:1>]]);
recipes.addShaped(<simplyjetpacks:components:12>,[  [<ore:ingotInvar>, <ThermalExpansion:material:1>, <ore:ingotInvar>],
						              [<ThermalDynamics:ThermalDynamics_0:1>, <MineFactoryReloaded:upgrade.logic>, <ThermalDynamics:ThermalDynamics_0:1>],
							          [<ThermalExpansion:Cell:2>, <ThermalExpansion:material>, <ThermalExpansion:Cell:2>]]);
recipes.addShaped(<simplyjetpacks:components:13>,[  [<ore:ingotElectrumFlux>, <ThermalExpansion:material:1>, <ore:ingotElectrumFlux>],
						              [<ThermalDynamics:ThermalDynamics_0:3>, <MineFactoryReloaded:upgrade.logic:1>, <ThermalDynamics:ThermalDynamics_0:3>],
							          [<ThermalExpansion:Cell:3>, <ThermalExpansion:material>, <ThermalExpansion:Cell:3>]]);
recipes.addShaped(<simplyjetpacks:components:14>,[  [oreDict.ingotEnderium, <ThermalExpansion:material:1>, oreDict.ingotEnderium],
						              [<ThermalDynamics:ThermalDynamics_0:2>, <MineFactoryReloaded:upgrade.logic:2>, <ThermalDynamics:ThermalDynamics_0:2>],
							          [<ThermalExpansion:Cell:4>, <ThermalExpansion:material>, <ThermalExpansion:Cell:4>]]);

// --- PneumaticServo ---

recipes.remove(<ThermalExpansion:material>);
recipes.addShaped(<ThermalExpansion:material>,[ [null, <TConstruct:materials:2>, null],
						           [<ore:blockGlass>, <minecraft:redstone>, <ore:blockGlass>],
							       [null, <TConstruct:materials:2>, null]]);

// --- MachineFrame ---

recipes.remove(<ThermalExpansion:Frame>);
recipes.addShaped(<ThermalExpansion:Frame>,[ [<ore:ingotInvar>, <ore:ingotElectrum>, <ore:ingotInvar>],
						         [<ore:blockGlass>, <MineFactoryReloaded:upgrade.logic>, <ore:blockGlass>],
							     [<ore:ingotInvar>, <ore:ingotElectrum>, <ore:ingotInvar>]]);

// --- AqueousAccumulator ---

recipes.remove(<ThermalExpansion:Machine:8>);
recipes.addShaped(<ThermalExpansion:Machine:8>.withTag({Level: 0 as byte}),[[<extracells:storage.fluid:3>, <minecraft:bucket>, <extracells:storage.fluid:3>],
						              [<ore:blockGlassHardened>, <ThermalExpansion:Frame>, <ore:blockGlassHardened>],
							          [<ore:blockEnderium>, <ThermalExpansion:material>, <ore:blockEnderium>]]);
recipes.addShaped(<ThermalExpansion:Machine:8>.withTag({Level: 1 as byte}),[[<ore:ingotInvar>, <ThermalFoundation:material:135>, <ore:ingotInvar>],
						              [null, <ThermalExpansion:Machine:8>.withTag({Level: 0 as byte}), null],
							          [<ore:ingotInvar>, null, <ore:ingotInvar>]]);
recipes.addShaped(<ThermalExpansion:Machine:8>.withTag({Level: 2 as byte}),[[<ore:blockGlassHardened>, <ThermalFoundation:material:138>, <ore:blockGlassHardened>],
						              [null, <ThermalExpansion:Machine:8>.withTag({Level: 1 as byte}), null],
							          [<ore:blockGlassHardened>, null, <ore:blockGlassHardened>]]);
recipes.addShaped(<ThermalExpansion:Machine:8>.withTag({Level: 3 as byte}),[[<ore:ingotSilver>, <ThermalFoundation:material:140>, <ore:ingotSilver>],
						              [null, <ThermalExpansion:Machine:8>.withTag({Level: 2 as byte}), null],
							          [<ore:ingotSilver>, null, <ore:ingotSilver>]]);

// --- Activator ---

recipes.remove(<ThermalExpansion:Device:2>);
recipes.addShaped(<ThermalExpansion:Device:2>,[[null, <minecraft:chest>, null],
						     [<ore:ingotTin>, <ThermalExpansion:Frame>, <ore:ingotTin>],
							 [null, <ThermalExpansion:material>, null]]);

// --- Dynamo ---

recipes.remove(<ThermalExpansion:Dynamo>);
recipes.remove(<ThermalExpansion:Dynamo:1>);
recipes.remove(<ThermalExpansion:Dynamo:2>);
recipes.remove(<ThermalExpansion:Dynamo:3>);
recipes.remove(<ThermalExpansion:Dynamo:4>);
recipes.remove(<PneumaticCraft:pneumaticDynamo>);
recipes.remove(<PneumaticCraft:fluxCompressor>);
NEI.hide(<ThermalExpansion:Dynamo:1>);
NEI.hide(<ThermalExpansion:Dynamo:4>);
NEI.hide(<PneumaticCraft:pneumaticDynamo>);

recipes.addShaped(<ThermalExpansion:Dynamo>,[[null, <ThermalExpansion:material:2>, null],
						       [<ore:gearCopper>, <ore:ingotCopper>, <ore:gearCopper>],
							   [<ore:ingotCopper>, <MineFactoryReloaded:upgrade.logic>, <ore:ingotCopper>]]);
recipes.addShaped(<ThermalExpansion:Dynamo:2>,[[null, <ThermalExpansion:material:2>, null],
						             [oreDict.gearTin, oreDict.ingotTin, oreDict.gearTin],
							         [oreDict.ingotTin, <MineFactoryReloaded:upgrade.logic>, oreDict.ingotTin]]);
recipes.addShaped(<ThermalExpansion:Dynamo:3>,[[null, <ThermalExpansion:material:2>, null],
						          [oreDict.gearBronze, oreDict.ingotBronze, oreDict.gearBronze],
                                  [oreDict.ingotBronze, <MineFactoryReloaded:upgrade.logic>, oreDict.ingotBronze]]);

recipes.addShaped(<PneumaticCraft:fluxCompressor>,[[null, <ThermalExpansion:material:1>, null],
						             [<ore:blockGlassHardened>, <ThermalExpansion:Frame>, <ore:blockGlassHardened>],
                                     [<PneumaticCraft:ingotIronCompressed>, <MineFactoryReloaded:upgrade.logic:1>, <PneumaticCraft:ingotIronCompressed>]]);

// --- TesseractFrame ---

recipes.remove(<ThermalExpansion:Frame:10>);
recipes.addShaped(<ThermalExpansion:Frame:10>,[[oreDict.ingotEnderium, <ore:blockGlassHardened>, oreDict.ingotEnderium],
						          [<ore:blockGlassHardened>, <MineFactoryReloaded:upgrade.logic:1>, <ore:blockGlassHardened>],
							      [oreDict.ingotEnderium, <ore:blockGlassHardened>, oreDict.ingotEnderium]]);

// --- FluidTransposer ---

mods.thermalexpansion.Transposer.addExtractRecipe(5000, <minecraft:leaves>, <liquid:water> * 100, <minecraft:sapling>, 5);
mods.thermalexpansion.Transposer.addExtractRecipe(5000, <minecraft:leaves:1>, <liquid:water> * 100, <minecraft:sapling:1>, 5);
mods.thermalexpansion.Transposer.addExtractRecipe(5000, <minecraft:leaves:2>, <liquid:water> * 100, <minecraft:sapling:2>, 5);
mods.thermalexpansion.Transposer.addExtractRecipe(5000, <minecraft:leaves:3>, <liquid:water> * 100, <minecraft:sapling:3>, 5);
mods.thermalexpansion.Transposer.addExtractRecipe(5000, <minecraft:leaves2>, <liquid:water> * 100, <minecraft:sapling:4>, 5);
mods.thermalexpansion.Transposer.addExtractRecipe(5000, <minecraft:leaves2:1>, <liquid:water> * 100, <minecraft:sapling:5>, 5);

mods.thermalexpansion.Transposer.addExtractRecipe(1600, <minecraft:sapling>, <liquid:water>*100, <minecraft:stick>, 100);
mods.thermalexpansion.Transposer.addExtractRecipe(1600, <minecraft:sapling:1>, <liquid:water>*100, <minecraft:stick>, 100);
mods.thermalexpansion.Transposer.addExtractRecipe(1600, <minecraft:sapling:2>, <liquid:water>*100, <minecraft:stick>, 100);
mods.thermalexpansion.Transposer.addExtractRecipe(1600, <minecraft:sapling:3>, <liquid:water>*100, <minecraft:stick>, 100);
mods.thermalexpansion.Transposer.addExtractRecipe(1600, <minecraft:sapling:4>, <liquid:water>*100, <minecraft:stick>, 100);
mods.thermalexpansion.Transposer.addExtractRecipe(1600, <minecraft:sapling:5>, <liquid:water>*100, <minecraft:stick>, 100);
mods.thermalexpansion.Transposer.addExtractRecipe(1600, <MineFactoryReloaded:rubberwood.sapling>, <liquid:water>*100, <minecraft:stick>, 100);



// --- Pulverizer ---

mods.thermalexpansion.Pulverizer.removeRecipe(<exnihilo:iron_dust>);
mods.thermalexpansion.Pulverizer.removeRecipe(<exnihilo:iron_sand>);
mods.thermalexpansion.Pulverizer.removeRecipe(<exnihilo:iron_gravel>);
mods.thermalexpansion.Pulverizer.removeRecipe(<exnihilo:nether_iron_gravel>);
mods.thermalexpansion.Pulverizer.removeRecipe(<exnihilo:gold_dust>);
mods.thermalexpansion.Pulverizer.removeRecipe(<exnihilo:gold_sand>);
mods.thermalexpansion.Pulverizer.removeRecipe(<exnihilo:gold_gravel>);
mods.thermalexpansion.Pulverizer.removeRecipe(<exnihilo:nether_gold_gravel>);
mods.thermalexpansion.Pulverizer.removeRecipe(<exnihilo:copper_dust>);
mods.thermalexpansion.Pulverizer.removeRecipe(<exnihilo:copper_sand>);
mods.thermalexpansion.Pulverizer.removeRecipe(<exnihilo:copper_gravel>);
mods.thermalexpansion.Pulverizer.removeRecipe(<exnihilo:nether_copper_gravel>);
mods.thermalexpansion.Pulverizer.removeRecipe(<exnihilo:tin_dust>);
mods.thermalexpansion.Pulverizer.removeRecipe(<exnihilo:tin_sand>);
mods.thermalexpansion.Pulverizer.removeRecipe(<exnihilo:tin_gravel>);
mods.thermalexpansion.Pulverizer.removeRecipe(<exnihilo:ender_tin_gravel>);
mods.thermalexpansion.Pulverizer.removeRecipe(<exnihilo:silver_dust>);
mods.thermalexpansion.Pulverizer.removeRecipe(<exnihilo:silver_sand>);
mods.thermalexpansion.Pulverizer.removeRecipe(<exnihilo:silver_gravel>);
mods.thermalexpansion.Pulverizer.removeRecipe(<exnihilo:ender_silver_gravel>);
mods.thermalexpansion.Pulverizer.removeRecipe(<exnihilo:lead_dust>);
mods.thermalexpansion.Pulverizer.removeRecipe(<exnihilo:lead_sand>);
mods.thermalexpansion.Pulverizer.removeRecipe(<exnihilo:lead_gravel>);
mods.thermalexpansion.Pulverizer.removeRecipe(<exnihilo:ender_lead_gravel>);
mods.thermalexpansion.Pulverizer.removeRecipe(<exnihilo:nickel_dust>);
mods.thermalexpansion.Pulverizer.removeRecipe(<exnihilo:nickel_sand>);
mods.thermalexpansion.Pulverizer.removeRecipe(<exnihilo:nickel_gravel>);
mods.thermalexpansion.Pulverizer.removeRecipe(<exnihilo:nether_nickel_gravel>);
mods.thermalexpansion.Pulverizer.removeRecipe(<exnihilo:platinum_dust>);
mods.thermalexpansion.Pulverizer.removeRecipe(<exnihilo:platinum_sand>);
mods.thermalexpansion.Pulverizer.removeRecipe(<exnihilo:platinum_gravel>);
mods.thermalexpansion.Pulverizer.removeRecipe(<exnihilo:ender_platinum_gravel>);

mods.thermalexpansion.Pulverizer.addRecipe(4000,<exnihilo:aluminum_gravel>, <exnihilo:aluminum_sand>, <exnihilo:exnihilo.aluminum_crushed>, 40);
mods.thermalexpansion.Pulverizer.addRecipe(4000,<exnihilo:aluminum_sand>, <exnihilo:aluminum_dust>, <exnihilo:exnihilo.aluminum_powdered>, 40);

mods.thermalexpansion.Pulverizer.addRecipe(4000,<exnihilo:copper_gravel>, <exnihilo:copper_sand>, <exnihilo:exnihilo.copper_crushed>, 40);
mods.thermalexpansion.Pulverizer.addRecipe(4000,<exnihilo:copper_sand>, <exnihilo:copper_dust>, <exnihilo:exnihilo.copper_powdered>, 40);

mods.thermalexpansion.Pulverizer.addRecipe(4000,<exnihilo:gold_gravel>, <exnihilo:gold_sand>, <exnihilo:exnihilo.gold_crushed>, 40);
mods.thermalexpansion.Pulverizer.addRecipe(4000,<exnihilo:gold_sand>, <exnihilo:gold_dust>, <exnihilo:exnihilo.gold_powdered>, 40);

mods.thermalexpansion.Pulverizer.addRecipe(4000,<exnihilo:iron_gravel>, <exnihilo:iron_sand>, <exnihilo:exnihilo.iron_crushed>, 40);
mods.thermalexpansion.Pulverizer.addRecipe(4000,<exnihilo:iron_sand>, <exnihilo:iron_dust>, <exnihilo:exnihilo.iron_powdered>, 40);

mods.thermalexpansion.Pulverizer.addRecipe(4000,<exnihilo:nickel_gravel>, <exnihilo:nickel_sand>, <exnihilo:exnihilo.nickel_crushed>, 40);
mods.thermalexpansion.Pulverizer.addRecipe(4000,<exnihilo:nickel_sand>, <exnihilo:nickel_dust>, <exnihilo:exnihilo.nickel_powdered>, 40);

mods.thermalexpansion.Pulverizer.addRecipe(4000,<exnihilo:platinum_gravel>, <exnihilo:platinum_sand>, <exnihilo:exnihilo.platinum_crushed>, 40);
mods.thermalexpansion.Pulverizer.addRecipe(4000,<exnihilo:platinum_sand>, <exnihilo:platinum_dust>, <exnihilo:exnihilo.platinum_powdered>, 40);

mods.thermalexpansion.Pulverizer.addRecipe(4000,<exnihilo:silver_gravel>, <exnihilo:silver_sand>, <exnihilo:exnihilo.silver_crushed>, 40);
mods.thermalexpansion.Pulverizer.addRecipe(4000,<exnihilo:silver_sand>, <exnihilo:silver_dust>, <exnihilo:exnihilo.silver_powdered>, 40);

mods.thermalexpansion.Pulverizer.addRecipe(4000,<exnihilo:tin_gravel>, <exnihilo:tin_sand>, <exnihilo:exnihilo.tin_crushed>, 40);
mods.thermalexpansion.Pulverizer.addRecipe(4000,<exnihilo:tin_sand>, <exnihilo:tin_dust>, <exnihilo:exnihilo.tin_powdered>, 40);