import mods.thermalexpansion.Furnace;
import mods.nei.NEI;

// ==========================================
// Removes Crafts/ Hide Itens
// ==========================================

recipes.remove(<enviromine:salty_cold_WaterBottle>);
recipes.remove(<enviromine:salty_warm_WaterBottle>);
recipes.remove(<enviromine:clean_warm_WaterBottle>);
recipes.removeShaped(<enviromine:dirty_WaterBottle>, [[<enviromine:dirty_warm_WaterBottle>],[<minecraft:snowball>]]);
recipes.remove(<enviromine:dirty_cold_WaterBottle>);
recipes.remove(<enviromine:dirty_warm_WaterBottle>);
recipes.remove(<enviromine:frosty_WaterBottle>);
recipes.remove(<enviromine:radioactive_WaterBottle>);
recipes.remove(<enviromine:radioactive_cold_WaterBottle>);
recipes.remove(<enviromine:radioactive_frosty_WaterBottle>);
recipes.remove(<enviromine:radioactive_hot_WaterBottle>);
recipes.remove(<enviromine:radioactive_warm_WaterBottle>);
recipes.remove(<enviromine:salty_WaterBottle>);
recipes.remove(<minecraft:potion:0>);
furnace.remove(<enviromine:salty_WaterBottle>);
furnace.remove(<enviromine:clean_cold_WaterBottle>);
furnace.remove(<enviromine:clean_warm_WaterBottle>);
furnace.remove(<enviromine:dirty_WaterBottle>);
furnace.remove(<enviromine:hot_WaterBottle>);
furnace.remove(<enviromine:radioactive_WaterBottle>);
furnace.remove(<enviromine:radioactive_warm_WaterBottle>);
furnace.remove(<enviromine:radioactive_hot_WaterBottle>);
furnace.remove(<enviromine:radioactive_cold_WaterBottle>);

mods.thermalexpansion.Furnace.removeRecipe(<minecraft:potion:0>);
mods.thermalexpansion.Furnace.removeRecipe(<enviromine:clean_warm_WaterBottle>);
mods.thermalexpansion.Furnace.removeRecipe(<enviromine:clean_cold_WaterBottle>);
mods.thermalexpansion.Furnace.removeRecipe(<enviromine:dirty_cold_WaterBottle>);
mods.thermalexpansion.Furnace.removeRecipe(<enviromine:dirty_WaterBottle>);
mods.thermalexpansion.Furnace.removeRecipe(<enviromine:dirty_warm_WaterBottle>);
mods.thermalexpansion.Furnace.removeRecipe(<enviromine:radioactive_cold_WaterBottle>);
mods.thermalexpansion.Furnace.removeRecipe(<enviromine:frosty_WaterBottle>);
mods.thermalexpansion.Furnace.removeRecipe(<enviromine:radioactive_frosty_WaterBottle>);
mods.thermalexpansion.Furnace.removeRecipe(<enviromine:radioactive_WaterBottle>);
mods.thermalexpansion.Furnace.removeRecipe(<enviromine:radioactive_warm_WaterBottle>);
mods.thermalexpansion.Furnace.removeRecipe(<enviromine:salty_WaterBottle>);
mods.thermalexpansion.Furnace.removeRecipe(<enviromine:salty_warm_WaterBottle>);
mods.thermalexpansion.Furnace.removeRecipe(<enviromine:salty_cold_WaterBottle>);

NEI.hide(<enviromine:radioactive_frosty_WaterBottle>);
NEI.hide(<enviromine:radioactive_cold_WaterBottle>);
NEI.hide(<enviromine:radioactive_WaterBottle>);
NEI.hide(<enviromine:radioactive_warm_WaterBottle>);
NEI.hide(<enviromine:radioactive_hot_WaterBottle>);
NEI.hide(<enviromine:frosty_WaterBottle>);
NEI.hide(<enviromine:clean_warm_WaterBottle>);
NEI.hide(<enviromine:hot_WaterBottle>);
NEI.hide(<enviromine:dirty_cold_WaterBottle>);
NEI.hide(<enviromine:dirty_warm_WaterBottle>);
NEI.hide(<enviromine:salty_cold_WaterBottle>);
NEI.hide(<enviromine:salty_warm_WaterBottle>);

// ==========================================
// Add Crafts
// ==========================================

recipes.addShaped(<enviromine:dirty_WaterBottle> , [[<minecraft:glass_bottle>, <minecraft:dirt>]]);
recipes.addShaped(<enviromine:salty_WaterBottle> , [[<minecraft:potion:0>, <minecraft:sand>]]);
recipes.addShaped(<minecraft:potion:0> ,
[[<minecraft:cactus>, <minecraft:cactus>, <minecraft:cactus>],
[<minecraft:cactus>, <minecraft:glass_bottle>, <minecraft:cactus>],
[<minecraft:cactus>, <minecraft:cactus>, <minecraft:cactus>]]);
furnace.addRecipe(<harvestcraft:saltItem> * 4, <enviromine:salty_WaterBottle>);
furnace.addRecipe(<minecraft:potion:0>, <enviromine:dirty_WaterBottle>);