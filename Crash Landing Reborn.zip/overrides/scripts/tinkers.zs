recipes.remove(<TConstruct:blankPattern>);
recipes.remove(<TConstruct:CraftedSoil:1>);


recipes.addShaped(<TConstruct:blankPattern> ,
[[<ore:plankWood>, <minecraft:stick>,],
[<minecraft:stick>, <ore:plankWood>, ]]);
recipes.addShaped(<TConstruct:blankPattern> ,
[[<minecraft:stick>, <minecraft:stick>,],
[<minecraft:stick>, <minecraft:stick>, ]]);
recipes.addShapeless(<TConstruct:heartCanister:6>,[<TConstruct:heartCanister:4>,<TConstruct:heartCanister>,<minecraft:nether_star>]);